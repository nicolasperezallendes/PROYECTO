# Lecciones aprendidas (técnicas y de proceso)

Léelas antes de usar las herramientas. Cada lección nueva se agrega con su fecha.

## API de Mercado Público

- **Ticket:** se lee de `MERCADOPUBLICO_TICKET` o de `herramientas/mercadopublico/.env`. Nunca se sube a git: `.env` está en `.gitignore`. Las sesiones en la nube son efímeras, así que lo ideal es que el usuario lo guarde como variable de entorno del entorno de trabajo.
- **No acepta consultas simultáneas** (error 10500). El script consulta de una en una, con una pausa de 1 segundo y reintentos.
- **Velocidad:** cada ficha de detalle tarda entre 2 y 3 segundos. Revisar 100 licitaciones toma unos 4 minutos.
- **Cupo diario limitado:** no se bajan todas las fichas del país. Primero se filtra por nombre y luego se revisa el detalle de las mejores.
- **El listado trae los nombres cortados** (unos 50 caracteres). El nombre completo y la descripción están en el detalle.
- **Monedas:** `Moneda` puede ser CLP, CLF (que es UF) o USD. Por ejemplo, 3.400 en CLF son 3.400 UF, no $3.400.
- **Montos ocultos:** con `VisibilidadMonto` igual a 0, el monto no se publica. Hay que decir "no publica", no "$0".
- **Códigos de rubro:** los productos usan UNSPSC de 8 dígitos, pero también hay categorías propias de ChileCompra de 9 dígitos que **sí aparecen en las licitaciones**. Se había supuesto lo contrario y se corrigió el 19-10-2026. Por ejemplo, la categoría 102000000 "Consultoría", con el producto 102101001 "Planificación y Factibilidad", aparece en unas 20 de cada 166 licitaciones de consultoría, casi todas del MOP y de ingeniería. `postulables.py` compara cada código solo con códigos de su mismo largo.
- **Cómo revisar qué rubros se usan:** baja el detalle de las licitaciones activas cuyo nombre tenga consultoría, asesoría, estudio, diagnóstico, encuesta, evaluación, investigación o capacitación (sin obras ni suministros), y cuenta los `CodigoCategoria` de sus ítems. Lo hace `rubros_en_uso.py` en unos 7 minutos. El resultado del 19-10-2026 está en `rubros-consultoria.md`.
- **Unidades de la Municipalidad de Coquimbo:** 2446 es la municipal central y 2448 el Departamento de Salud (organismo 87901).
- **Ruido conocido del filtro por nombre:** "diseño" trae ingeniería y arquitectura, como puentes, ciclovías, paraderos, plazas y edificios. "Capacitación" trae franquicias y seguros. Ya están en `excluir`.

## API de Compra Ágil (v2, beta)

Agregado el 19-10-2026, a partir de chilecompra.cl/api y de la documentación en PDF de mayo de 2026.

- **Existe desde el 22-05-2026.** Antes, la API v1 no traía las solicitudes de cotización de Compra Ágil (ChileCompra lo confirmó en febrero de 2025). Ahora tiene su propia API, en versión beta.
- **Rutas:** la base es `https://api2.mercadopublico.cl`. El listado está en `/v2/compra-agil` y el detalle en `/v2/compra-agil/{codigo}` (los códigos son del tipo `1195-39-COT26`). La guía también usa `/v2/compraagil`, sin guion, y `compras_agiles.py` prueba las dos.
- **Ticket:** va en el header `ticket`, no en la URL. Se pide en chilecompra.cl/api con Clave Única. Falta confirmar que el ticket actual de JUNCOS sirve también para esta API.
- **Estados:** `publicada` (abierta y recibiendo cotizaciones), `cerrada`, `desierta`, `cancelada` y `proveedor_seleccionado`.
- **Filtros:** estado, región (de 1 a 16; Coquimbo debería ser 4, hay que verificarlo), texto (`q`) y fechas en ISO-8601. No hay filtro por organismo ni por rubro, así que se filtra en el script.
- **Paginación:** hasta 50 registros por página.
- **Cuota diaria por ticket:** al agotarse responde 429, y se reinicia al cambiar el día. Por eso el script filtra por nombre antes de bajar detalles, y por defecto solo mira las publicadas en los últimos 3 días.
- **Monto:** `monto_disponible_clp` está en `montos` en el listado y en `presupuesto` en el detalle. Incluye impuestos.
- **Sin confirmar:**
  - si `codigo_producto` es UNSPSC de 8 dígitos o un código propio;
  - el enlace público a la ficha de cada Compra Ágil;
  - si la API muestra el plazo para aceptar la orden de compra.
  Revísalo en la primera corrida y corrige el script.
- **Pruebas:** `compras_agiles.py` se probó el 19-10-2026 contra una API simulada, no contra la real. La sesión del chat de claude.ai no tenía red hacia mercadopublico.cl ni ticket.
- **Las órdenes de compra de Compra Ágil** aparecen en la API v1 de órdenes con el tipo AG. Sirven para ver quién ganó y a qué precio.

## Portal web

- **La ficha pública de la licitación** (`DetailsAcquisition.aspx`) es HTML normal y trae el resumen de las bases. Se lee con `mercadopublico.py ficha-web`. Lo mismo vale para el foro (`/Foros/.../PublicView.aspx`).
- **Los adjuntos** (`Attachment/ViewAttachment.aspx`) están protegidos con reCAPTCHA Enterprise. **No se evade:** ni llamando directo a `ViewAttachmentLC.aspx`, ni con navegadores automatizados, ni con servicios para resolver CAPTCHAs como CapSolver. El usuario ya lo pidió dos veces y se rechazó: es un control de acceso del sitio y arriesga bloqueos para la empresa. La vía es que Nicolás descargue los archivos desde "Ver adjuntos" y los suba, o que se use Claude en Chrome en una sesión en su computador, donde el navegador hace la verificación normal y él resuelve el desafío si aparece.
- **OCDS** (`apis.mercadopublico.cl/OCDS/data/record/CODIGO`): las licitaciones recientes aún no aparecen (devuelve 404).
- **La ficha pública del proveedor** (`proveedor.mercadopublico.cl/ficha/2103594`) se arma con JavaScript y casi no trae datos. No muestra los rubros.
- **Los rubros y los datos internos de la empresa** solo se ven con sesión iniciada (Mi empresa). El 19-10-2026 se leyeron con un enlace de sesión que entregó el usuario. Funcionó solo cuando él aprobó el comando con el modo de permisos fuera de "Auto". Después se borró de inmediato el enlace y todo lo capturado, que incluía una consulta de cuentas bancarias. Repetir solo con autorización explícita, solo lectura y borrando todo al terminar.
- **Certificados del entorno:** nunca desactives la verificación TLS (`--ignore-certificate-errors`). El navegador del entorno ya confía en el certificado del proxy.

## Entorno de trabajo

- **El acceso a mercadopublico.cl depende de la sesión.** En una sesión en la nube del 19-10-2026 la red no llegaba a mercadopublico.cl. En otra del mismo día (rama `claude/stoic-darwin-gi9n29`) la API y la ficha pública funcionaron sin problema. En el chat del proyecto JUNCOS en claude.ai, también el 19-10-2026, no hubo red hacia `api.mercadopublico.cl` ni hacia `api2.mercadopublico.cl`. Prueba primero con `python3 mercadopublico.py organismos coquimbo`. Si falla por red, lee la ficha y el foro con Claude en Chrome o corre los scripts en el computador del usuario.
- **Para hacer push**, el repositorio `nicolasperezallendes/PROYECTO` tiene que estar agregado como fuente de la sesión, con permiso de escritura. Si no lo está, entrega los archivos por el chat y avisa que el commit quedó solo en el entorno. Así se perdieron el programa de integridad y el borrador de propuesta de 564953-79-LE26 del 19-10-2026: se hicieron en otra sesión y no llegaron a GitHub.
- Las sesiones en la nube **no pueden usar el Chrome del usuario**. Para eso hay que trabajar en la app de escritorio o con `claude remote-control` en su computador, con la extensión Claude en Chrome conectada.
- El trabajo se guarda con commits y push en la rama del proyecto. Lo que queda solo en el contenedor se pierde.

## Proceso y redacción

- **Verifica siempre el día de la semana** de cada fecha con `date -d AAAA-MM-DD +%A`. El 19-10-2026 se escribió "jueves 23" cuando era viernes, y hubo que corregir dos informes.
- **Conteos:** revisa los totales contra la tabla antes de entregar. Hubo que corregir "cuatro" por "tres" procesos sin monto.
- Los informes abren con la conclusión y las recomendaciones, y el detalle va después.
- No inventes datos de la empresa: pídeselos al usuario. El correo del usuario no se escribe en documentos sin que él lo entregue para ese fin.
- Cuando una vía falla o se bloquea, dilo claro, explica la alternativa y sigue con lo que sí se puede hacer. No rellenes con datos supuestos.
